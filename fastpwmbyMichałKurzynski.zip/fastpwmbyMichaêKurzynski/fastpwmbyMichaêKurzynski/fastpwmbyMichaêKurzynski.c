#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <Util/delay.h>

void initializer(void)
{
	TCCR0|= (1<<WGM00)|(1<<WGM01)|(1<<CS02)|(0<<CS01)|(1<<CS00)|(0<<COM01)|(0<<COM00);
	OCR0=255;
	TIMSK|=(1<<OCIE0)|(1<<TOIE0);
	//DDRB|= (1<<PB3);
	DDRA|=0xFF;
}

ISR(TIMER0_COMP_vect)
{
	PORTA=0xF0;
}

ISR(TIMER0_OVF_vect)
{
	PORTA=0x0F;
}

int main(void)
{
	initializer();
	sei();
	while(1)
	{
		OCR0++;
		_delay_ms(20);
		//TODO:: Please write your application code
	}
}

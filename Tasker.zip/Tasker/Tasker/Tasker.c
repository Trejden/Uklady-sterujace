#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/io.h>
#include <avr/interrupt.h>

#define    MAX_TASK 10
#define NULL_TASK 0
#define NON_PERIODIC 0


typedef void (*TASK_PTR)(void);

typedef struct{
	TASK_PTR task;
	uint8_t ready;
	uint16_t togo;
	uint16_t periodic;
}TASK;

TASK tablica[MAX_TASK];
unsigned char liczbataskow=0;
int pierwsza=0;
int druga=0;
int trzecia=0;
int czwarta=0;


void scheduler(void);
void dodajtaska(TASK_PTR tsk, uint16_t period, uint16_t);

void init(void)
{
	for(int i=0;i<10;i++)
	{
		tablica[i].task = 0;
		tablica[i].ready=0;
		tablica[i].togo=0;
		tablica[i].periodic=NON_PERIODIC;
	}

}
void kernelinit(void)
{
	TIMSK|=(1<<OCIE0);
	TCCR0|= (0<<WGM00)|(1<<WGM01)|(0<<CS02)|(1<<CS01)|(1<<CS00)|(0<<COM01)|(0<<COM00);
	OCR0=250;
}


void scheduler(void)
{
	int taskcounter=0;

	while(1)
	{
		if(tablica[taskcounter].ready>0)
		{
			tablica[taskcounter].ready--;
			tablica[taskcounter].task();
			taskcounter=0;
		}
		else
		{
			if(taskcounter+1<liczbataskow)
			taskcounter++;
			else
			taskcounter=0;
		}
	}
}

void dodajtaska(TASK_PTR tsk, uint16_t period, uint16_t zaile)
{
	tablica[liczbataskow].task=tsk;
	tablica[liczbataskow].periodic=period;
	tablica[liczbataskow].togo=zaile;
	liczbataskow++;
}

void task1(void)
{
	pierwsza++;
}
void task2(void)
{
	druga++;
}
void task3(void)
{
	trzecia++;
}
void task4(void)
{
	czwarta++;
}

int main(void)
{
	init();
	dodajtaska(&task1,4,0);
	dodajtaska(&task2,4,4);
	dodajtaska(&task3,4,4);
	dodajtaska(&task4,4,4);
	kernelinit();
	sei();
	scheduler();
}



ISR(TIMER0_COMP_vect)
{
	for(int i=0;i<liczbataskow;i++)
	{
		if(tablica[i].togo==0)
		{
			tablica[i].ready++;
			tablica[i].togo=tablica[i].periodic;
		}
		else
		{
			tablica[i].togo--;
		}
	}
}